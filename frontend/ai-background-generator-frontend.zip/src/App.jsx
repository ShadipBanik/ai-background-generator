import React, { useState } from 'react';

function App() {
  const [image, setImage] = useState(null);
  const [fgUrl, setFgUrl] = useState('');
  const [bgPrompt, setBgPrompt] = useState('');
  const [bgUrl, setBgUrl] = useState('');
  const [finalUrl, setFinalUrl] = useState('');

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    setImage(file);
    const formData = new FormData();
    formData.append("file", file);
    const res = await fetch("http://localhost:8000/remove-background", {
      method: "POST",
      body: formData,
    });
    const data = await res.json();
    setFgUrl("http://localhost:8000/" + data.image_url);
  };

  const handleGenerateBg = async () => {
    const res = await fetch("http://localhost:8000/generate-background?prompt=" + encodeURIComponent(bgPrompt), {
      method: "POST"
    });
    const data = await res.json();
    setBgUrl("http://localhost:8000/" + data.bg_url);
  };

  const handleCompose = async () => {
    const formData = new FormData();
    formData.append("foreground", image);
    const bgBlob = await fetch(bgUrl).then(r => r.blob());
    const bgFile = new File([bgBlob], "bg.png");
    formData.append("background", bgFile);

    const res = await fetch("http://localhost:8000/compose", {
      method: "POST",
      body: formData
    });

    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    setFinalUrl(url);
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1>AI Background Generator</h1>
      <input type="file" onChange={handleUpload} />
      <br /><br />
      {fgUrl && <img src={fgUrl} alt="Foreground" width={200} />}
      <br /><br />
      <input
        type="text"
        placeholder="Describe background (e.g., beach, forest)"
        value={bgPrompt}
        onChange={e => setBgPrompt(e.target.value)}
      />
      <button onClick={handleGenerateBg}>Generate Background</button>
      <br /><br />
      {bgUrl && <img src={bgUrl} alt="Background" width={200} />}
      <br /><br />
      <button onClick={handleCompose}>Compose Final Image</button>
      <br /><br />
      {finalUrl && <img src={finalUrl} alt="Composed" width={300} />}
    </div>
  );
}

export default App;
